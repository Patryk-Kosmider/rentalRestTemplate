package pl.pjatk.rental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
