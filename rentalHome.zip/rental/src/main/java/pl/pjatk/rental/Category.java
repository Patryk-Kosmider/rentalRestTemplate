package pl.pjatk.rental;

public enum Category {
    Akcja,
    Komedia,
    Bajka,
    Dramat;
}